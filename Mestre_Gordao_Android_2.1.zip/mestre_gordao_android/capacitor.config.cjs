const config = {
  appId: 'com.mestregordao.rpg',
  appName: 'Mestre Gordão',
  webDir: 'www',
  bundledWebRuntime: false
};
module.exports = config;
